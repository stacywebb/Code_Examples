To use Python OAuthUtil you need to install the Google python oauth egg.
Unzip /components/simplegeo... and follow installation instructions.