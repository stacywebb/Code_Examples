from tenant.wgu.models import *
from django.contrib import admin

admin.site.register(RedemptionProgram)


