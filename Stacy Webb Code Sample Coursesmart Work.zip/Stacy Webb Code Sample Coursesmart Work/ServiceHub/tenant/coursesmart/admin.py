from tenant.coursesmart.models import *
from django.contrib import admin

admin.site.register(RedirectorTemplate)


