from core.models import *
from django.contrib import admin

admin.site.register(Tenant)
admin.site.register(EResource)
admin.site.register(SiteUser)
admin.site.register(Course)
admin.site.register(CourseRequirement)

