from security.models import *
from django.contrib import admin

admin.site.register(UserIdentity)


